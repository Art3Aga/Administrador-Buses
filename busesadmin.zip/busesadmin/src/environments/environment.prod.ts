export const environment = {
  production: true,
  mapboxKey: 'pk.eyJ1IjoiYXJ0ZWFnYSIsImEiOiJjazB6anBsZXUwcXhuM2hwZnUzanMwNzd0In0.gAlg4pXJZvUQ12WWKJgmUQ'
};
