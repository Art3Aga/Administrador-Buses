export interface IUsuario {
  nombre_usuario: string;
}
