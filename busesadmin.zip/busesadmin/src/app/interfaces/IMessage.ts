export interface IMessage {
  mensaje: string;
  objeto: any;
}
