export interface IBuses {
  id_bus?: string;
  nombre_bus: string;
  nombre_motorista?: string;
  placa: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
  imgPath?: string;
  id_horario?: string;
  id_ruta?: string;
  nombre_ruta?: string;
}
