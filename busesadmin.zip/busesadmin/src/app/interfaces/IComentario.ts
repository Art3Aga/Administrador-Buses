export interface IComentario {
  texto: string;
  nombre_usuario: string;
  fecha: string;
}
