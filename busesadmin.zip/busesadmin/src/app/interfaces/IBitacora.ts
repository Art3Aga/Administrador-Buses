export interface IBitacora {
  id_bitacora?: string;
  id_admin: string;
  mensaje: string;
  titulo: string;
  fecha: string;
}
