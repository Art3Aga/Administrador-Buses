export interface IParadas {
  id_parada?: string;
  nombre_parada: string;
  nombre_ruta: string;
  latitud: string;
  longitud: string;
  namelnglat?: string;
}
