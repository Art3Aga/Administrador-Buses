export interface IAdmins {
  id_admin?: string;
  usuario: string;
  clave: string;
}
